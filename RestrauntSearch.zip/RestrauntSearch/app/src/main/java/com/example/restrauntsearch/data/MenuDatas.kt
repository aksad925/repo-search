package com.example.restrauntsearch.data

data class MenuDatas(
    val menus: List<Menu>
)
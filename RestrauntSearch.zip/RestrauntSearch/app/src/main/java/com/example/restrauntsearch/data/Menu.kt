package com.example.restrauntsearch.data

data class Menu(
    val categories: List<Category>,
    val restaurantId: Int
)
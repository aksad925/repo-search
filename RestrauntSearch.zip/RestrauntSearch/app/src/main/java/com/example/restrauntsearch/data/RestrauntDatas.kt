package com.example.restrauntsearch.data

data class RestrauntDatas(
    val restaurants: List<Restaurant>
)
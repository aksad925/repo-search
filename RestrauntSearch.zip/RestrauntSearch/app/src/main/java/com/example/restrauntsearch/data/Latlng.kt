package com.example.restrauntsearch.data

data class Latlng(
    val lat: Double,
    val lng: Double
)